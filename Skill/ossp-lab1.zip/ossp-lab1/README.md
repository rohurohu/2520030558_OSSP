# OSSP (Operating Systems And Systems Programming) — 25CS2104E
### Skill Content Delivery Concepts — Lab 1

This repository covers both parts of the assignment:

1. **Environment setup** — Linux VM, GCC, Git, project structure, shell architecture, initial Makefile
2. **Process management** — process abstraction, `fork()`, the `exec()` family, parent-child relationships, the process tree, and system-call tracing

Repo contents:

```
ossp-lab1/
├── README.md              <- this file (Task 1 write-up + how to run everything)
├── Makefile                <- builds every program in src/ into bin/
├── .gitignore
├── src/
│   ├── fork_demo.c          Task 2.1 — process abstraction & fork()
│   ├── exec_demo.c          Task 2.2 — the exec() family
│   ├── process_tree.c       Task 2.3/2.4 — parent-child relationships & process tree
│   └── syscall_demo.c       Task 2.5 — target program for strace
└── docs/
    └── OSSP_Lab1_Report.docx  <- full lab report (explanations + captured output)
```

---

## Part 1 — Environment Setup

### 1.1 Install a Linux VM
Any recent Ubuntu LTS works well for this course.
1. Download **VirtualBox** (or VMware Workstation Player) and an **Ubuntu 22.04/24.04 LTS** ISO.
2. Create a new VM: ≥ 2 CPU cores, ≥ 4 GB RAM, ≥ 25 GB disk.
3. Boot the ISO and run the installer with default partitioning.
4. After install, run:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

### 1.2 Configure GCC
Ubuntu ships GCC via the `build-essential` metapackage, which also pulls in `make` and standard headers:
```bash
sudo apt install -y build-essential
gcc --version     # confirm install
```
This environment is already running **GCC 13.3.0** (verified while building this repo).

### 1.3 Set up a Git repository
```bash
git config --global user.name  "Your Name"
git config --global user.email "you@example.com"

mkdir ossp-lab1 && cd ossp-lab1
git init
git add .
git commit -m "Initial commit: project structure, Makefile, process demos"

# create an empty repo on GitHub first, then:
git branch -M main
git remote add origin https://github.com/<your-username>/ossp-lab1.git
git push -u origin main
```

### 1.4 Project structure
See the tree above — sources in `src/`, build output in `bin/` (git-ignored, produced by `make`), documentation in `docs/`.

### 1.5 Understand shell architecture
The shell (`bash`, `sh`, `zsh`, …) is a **user-space program**, not part of the kernel. Its job:
1. **Read** a line of input (interactively, or from a script).
2. **Parse** it into a command + arguments.
3. **Fork** a child process (`fork()`).
4. Have the child **replace itself** with the requested program (`execve()`/`execvp()`).
5. The shell (parent) **waits** for that child to finish, then prints a new prompt.

This is exactly the `fork()` + `exec()` + `wait()` pattern reproduced in `src/exec_demo.c` — running any command from a shell *is* this pattern.

### 1.6 Build the initial Makefile
See `Makefile` at the project root. It auto-discovers every `.c` file in `src/`, compiles each with `-Wall -Wextra` into `bin/`, and exposes convenience targets:

```bash
make            # build everything into bin/
make run-fork   # build (if needed) and run fork_demo
make run-exec   # build (if needed) and run exec_demo
make run-tree   # build (if needed) and run process_tree
make run-trace  # build, then strace the syscall_demo target -> trace_output.txt
make clean      # remove bin/ and generated *.txt artifacts
```

---

## Part 2 — Process Management

| File | What it shows | Run it |
|---|---|---|
| `src/fork_demo.c` | Process abstraction, `fork()` return values, `wait()` | `make run-fork` |
| `src/exec_demo.c` | `execl()` and `execvp()` replacing a process image | `make run-exec` |
| `src/process_tree.c` | 3-generation parent → child → grandchild tree, verified with `pstree -p` | `make run-tree` |
| `src/syscall_demo.c` | Target program for tracing `open/write/read/close/fork/exit` with `strace` | `make run-trace` |

Full explanations of *why* each demo behaves the way it does (including two real buffering/`_exit()` gotchas we hit while building this) are in **`docs/OSSP_Lab1_Report.docx`**, along with the actual captured terminal output from every run.

### Quick start
```bash
git clone https://github.com/<your-username>/ossp-lab1.git
cd ossp-lab1
make
make run-fork
make run-exec
make run-tree
make run-trace && cat trace_output.txt
```
