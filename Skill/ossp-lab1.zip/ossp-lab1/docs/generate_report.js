const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  Header, Footer, PageNumber, NumberFormat, TabStopType, TabStopPosition,
} = require("docx");

// ---------- helpers ----------------------------------------------------

const MONO = "Consolas";
const CODE_FILL = "F2F2F2";
const OUTPUT_FILL = "1E1E1E";

function h1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 200 } });
}
function h2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 150 } });
}
function h3(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_3, spacing: { before: 200, after: 100 } });
}
function p(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts })],
    spacing: { after: 160 },
  });
}
function bullet(text) {
  return new Paragraph({ text, bullet: { level: 0 }, spacing: { after: 80 } });
}
function numbered(text, opts = {}) {
  return new Paragraph({ text, numbering: { reference: "steps-numbering", level: 0 }, spacing: { after: 80 }, ...opts });
}

// A shaded, bordered "code block" made from a single-cell table (reliable
// background fill across Word/LibreOffice/Google Docs, unlike paragraph shading).
function codeBlock(codeText, { dark = false } = {}) {
  const lines = codeText.replace(/\t/g, "    ").split("\n");
  const fill = dark ? OUTPUT_FILL : CODE_FILL;
  const fontColor = dark ? "D4D4D4" : "1B1B1B";
  const paras = lines.map(
    (line) =>
      new Paragraph({
        children: [
          new TextRun({
            text: line.length ? line : " ",
            font: MONO,
            size: 18, // 9pt
            color: fontColor,
          }),
        ],
        spacing: { after: 0 },
      })
  );
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    columnWidths: [9350],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: 9350, type: WidthType.DXA },
            shading: { type: ShadingType.CLEAR, fill },
            margins: { top: 120, bottom: 120, left: 150, right: 150 },
            borders: {
              top: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
              bottom: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
              left: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
              right: { style: BorderStyle.SINGLE, size: 4, color: "BFBFBF" },
            },
            children: paras,
          }),
        ],
      }),
    ],
  });
}

function afterTableSpacer() {
  return new Paragraph({ text: "", spacing: { after: 200 } });
}

function caption(text) {
  return new Paragraph({
    children: [new TextRun({ text, italics: true, size: 20, color: "555555" })],
    spacing: { after: 240 },
  });
}

function readSrc(name) {
  return fs.readFileSync(path.join(__dirname, "..", "src", name), "utf8");
}
function readTxt(p2) {
  return fs.readFileSync(p2, "utf8");
}

// ---------- content ------------------------------------------------------

const forkOut = readTxt("/tmp/out_fork.txt");
const execOut = readTxt("/tmp/out_exec.txt");
const treeOut = readTxt("/tmp/out_tree.txt");
const syscallPlainOut =
  "Read back from file: System call tracing demo\nParent PID=809 done.";
const traceExcerpt = `782   openat(AT_FDCWD, "syscall_demo_scratch.txt", O_WRONLY|O_CREAT|O_TRUNC, 0644) = 3
782   write(3, "System call tracing demo\\n", 25) = 25
782   close(3)                          = 0
782   openat(AT_FDCWD, "syscall_demo_scratch.txt", O_RDONLY) = 3
782   read(3, "System call tracing demo\\n", 63) = 25
782   close(3)                          = 0
782   clone(child_stack=NULL, flags=CLONE_CHILD_CLEARTID|CLONE_CHILD_SETTID|SIGCHLD <unfinished ...>
783   set_robust_list(0x7f998e230a20, 24 <unfinished ...>
782   <... clone resumed>, child_tidptr=0x7f998e230a10) = 783
782   wait4(-1,  <unfinished ...>
783   getpid()                          = 783
783   exit_group(0)                     = ?
783   +++ exited with 0 +++
782   <... wait4 resumed>NULL, 0, NULL) = 783
782   --- SIGCHLD {si_signo=SIGCHLD, si_code=CLD_EXITED, si_pid=783, ...} ---
782   getpid()                          = 782
782   write(1, "Read back from file: System call"..., 67) = 67
782   exit_group(0)                     = ?
782   +++ exited with 0 +++`;

const doc = new Document({
  numbering: {
    config: [
      {
        reference: "steps-numbering",
        levels: [{ level: 0, format: NumberFormat.DECIMAL, text: "%1.", alignment: AlignmentType.START }],
      },
    ],
  },
  sections: [
    // ---------------- TITLE PAGE ----------------
    {
      properties: { page: { size: { width: 12240, height: 15840 } } }, // US Letter
      children: [
        new Paragraph({ text: "", spacing: { before: 2000 } }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "OSSP (Operating Systems And Systems Programming)", bold: true, size: 36 })],
          spacing: { after: 200 },
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "25CS2104E", bold: true, size: 28, color: "444444" })],
          spacing: { after: 400 },
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Skill Content Delivery Concepts — Lab 1 Report", bold: true, size: 30, color: "C00000" })],
          spacing: { after: 800 },
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Part 1: Environment & Tooling Setup", size: 24 })],
          spacing: { after: 120 },
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Part 2: Process Abstraction, fork(), exec(), Process Trees & System-Call Tracing", size: 24 })],
          spacing: { after: 1200 },
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Repository: ossp-lab1", size: 20, color: "666666" })],
        }),
      ],
    },

    // ---------------- MAIN CONTENT ----------------
    {
      properties: {},
      headers: {
        default: new Header({
          children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "OSSP 25CS2104E — Lab 1", size: 16, color: "888888" })] })],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({ children: [PageNumber.CURRENT], size: 18 }),
                new TextRun({ text: " / ", size: 18 }),
                new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18 }),
              ],
            }),
          ],
        }),
      },
      children: [
        h1("Overview"),
        p(
          "This report documents the two skill areas assigned for this lab: (1) setting up a Linux-based C development environment with Git and Make, and (2) writing and analysing C programs that exercise the core process-management primitives of a Unix-like OS — fork(), the exec() family, parent/child relationships, the resulting process tree, and system-call tracing with strace. Every code listing below was actually compiled with gcc -Wall -Wextra and executed; the terminal output shown is real output captured from those runs, not a mock-up."
        ),

        h1("Part 1 — Environment & Tooling Setup"),

        h2("1.1 Installing a Linux VM"),
        numbered("Download VirtualBox (or VMware Workstation Player) and an Ubuntu 22.04/24.04 LTS ISO."),
        numbered("Create a new VM with at least 2 CPU cores, 4 GB RAM, and 25 GB of disk space."),
        numbered("Boot the ISO and complete the Ubuntu installer with default (guided) partitioning."),
        numbered("After first boot, update the package index and installed packages:"),
        codeBlock("sudo apt update && sudo apt upgrade -y"),
        afterTableSpacer(),

        h2("1.2 Configuring GCC"),
        p("Ubuntu's build-essential metapackage installs GCC, Make, and the standard C headers/libraries in one step:"),
        codeBlock("sudo apt install -y build-essential\ngcc --version"),
        afterTableSpacer(),
        p("The environment used to build this repository reports GCC 13.3.0 (Ubuntu 13.3.0-6ubuntu2~24.04.1), confirmed with the command above."),

        h2("1.3 Setting up a Git repository"),
        codeBlock(
          `git config --global user.name  "Your Name"
git config --global user.email "you@example.com"

mkdir ossp-lab1 && cd ossp-lab1
git init
git add .
git commit -m "Initial commit: project structure, Makefile, process demos"

git branch -M main
git remote add origin https://github.com/<your-username>/ossp-lab1.git
git push -u origin main`
        ),
        afterTableSpacer(),

        h2("1.4 Project structure"),
        p("The repository is organised as:"),
        codeBlock(
          `ossp-lab1/
├── README.md
├── Makefile
├── .gitignore
├── src/
│   ├── fork_demo.c
│   ├── exec_demo.c
│   ├── process_tree.c
│   └── syscall_demo.c
└── docs/
    └── OSSP_Lab1_Report.docx`
        ),
        afterTableSpacer(),

        h2("1.5 Understanding shell architecture"),
        p(
          "A shell (bash, sh, zsh, ...) is an ordinary user-space program, not part of the kernel. Its core loop is:"
        ),
        bullet("Read a line of input, interactively or from a script."),
        bullet("Parse it into a command name plus arguments."),
        bullet("fork() a child process."),
        bullet("Have the child replace its own image with the requested program via execve()/execvp()."),
        bullet("The parent shell wait()s for that child, then prints the next prompt."),
        p(
          "This fork → exec → wait pattern is not just theory — it is exactly what Section 2.2's exec_demo.c does explicitly, and it is what your shell does silently every time you type any command."
        ),

        h2("1.6 Building the initial Makefile"),
        p("The project Makefile auto-discovers every .c file under src/, compiles each with warnings enabled, and links it into bin/:"),
        codeBlock(readSrcTrimmed("../Makefile")),
        afterTableSpacer(),
        p("Convenience targets: make (build all), make run-fork, make run-exec, make run-tree, make run-trace, and make clean."),

        h1("Part 2 — Process Management"),
        p(
          "Each subsection below follows the same format: what the program demonstrates, the C source, and the actual captured terminal output from running it in this environment."
        ),

        h2("2.1 Process abstraction and fork()"),
        p(
          "A process is the OS's abstraction of a running program: its own PID, its own virtual address space, its own copy of every variable, and its own set of open file descriptors — even if the program's source code is identical to another process's. fork() is the system call that creates a new process (the child) as a near-exact copy of the calling process (the parent) at the moment of the call. The single most important detail is fork()'s return value: it returns 0 in the child, the child's PID in the parent, and a negative value if it failed — that return value is the only way the two now-separate processes can tell which one they are."
        ),
        h3("Source: src/fork_demo.c"),
        codeBlock(readSrc("fork_demo.c")),
        afterTableSpacer(),
        h3("Captured output"),
        codeBlock(forkOut.trim(), { dark: true }),
        caption("Figure 1 — Output of ./bin/fork_demo. Note the child's PPID equals the parent's PID (645's PPID is 643), and the child's copy of the variable (150) is independent of the parent's copy (100) even though both started from the same value of 100 before fork()."),

        h2("2.2 The exec() family"),
        p(
          "exec() does not create a new process — it replaces the calling process's memory image (code, data, stack) with a different program, keeping the same PID. Combined with fork(), fork()+exec() is the standard Unix recipe for 'run this other program': fork() gets you a spare process, exec() turns that spare process into the program you actually wanted to run. Any code written after a successful exec() call never executes, because the program that contained it no longer exists in that process. This program shows two members of the family: execl() (arguments listed individually, ending in NULL) and execvp() (arguments passed as a NULL-terminated array, and the executable is searched for on $PATH)."
        ),
        h3("Source: src/exec_demo.c"),
        codeBlock(readSrc("exec_demo.c")),
        afterTableSpacer(),
        h3("Captured output"),
        codeBlock(execOut.trim(), { dark: true }),
        caption("Figure 2 — Output of ./bin/exec_demo. \"Hello from execl()...\" is not printed by our program — it is the output of /bin/echo, running inside a process that used to be our child. Likewise the file listing is real output from /bin/ls after execvp() replaced the second child's image."),

        h2("2.3 / 2.4 Parent-child relationships and the process tree"),
        p(
          "A parent can fork() more than one child, and any child can itself fork(), producing a multi-generation tree rather than a flat list. process_tree.c forks two children, and has each child fork one grandchild of its own, so the tree has three generations. Every process reports its own PID and its getppid() so the parent/child links can be verified directly from the output, and — while the grandchildren are still alive — the root process shells out to pstree -p to show the same tree from the operating system's point of view."
        ),
        h3("Source: src/process_tree.c"),
        codeBlock(readSrc("process_tree.c")),
        afterTableSpacer(),
        h3("Captured output"),
        codeBlock(treeOut.trim(), { dark: true }),
        caption(
          "Figure 3 — Output of ./bin/process_tree. Compare the PID/PPID values printed by the program itself (e.g. Child 1 = PID 770, PPID 768) against the independent pstree -p 768 snapshot taken from the OS: process_tree(768)-+-process_tree(770)---process_tree(771). Both agree, confirming the parent-child structure the program built."
        ),

        h2("2.5 System-call tracing with strace"),
        p(
          "strace intercepts and logs every system call a process makes (and, with -f, every system call its children make too) — it is the most direct way to see the boundary between a program and the kernel. syscall_demo.c deliberately performs a handful of very recognisable system calls: openat (creating and later re-opening a file), write and read, close, clone (the underlying syscall behind fork()), wait4 (behind wait()), and exit_group (behind exit()/_exit())."
        ),
        h3("Source: src/syscall_demo.c"),
        codeBlock(readSrc("syscall_demo.c")),
        afterTableSpacer(),
        h3("Normal run (no tracing)"),
        codeBlock(syscallPlainOut, { dark: true }),
        h3("Traced with: strace -f -o trace_output.txt ./bin/syscall_demo"),
        codeBlock(traceExcerpt, { dark: true }),
        caption(
          "Figure 4 — Relevant lines from trace_output.txt (dynamic-linker startup calls trimmed for brevity — the full trace is included when you run make run-trace). Notice clone(...) creates PID 783 as the child, wait4(-1, ...) is the parent blocking, and each process ends in exit_group()."
        ),

        h3("A bonus finding while building this: _exit() does not flush stdio buffers"),
        p(
          "The child process in syscall_demo.c calls printf(\"Child PID=%d saying hello...\") followed immediately by _exit(0) — yet that line never appears in either the normal run or the trace above. This is not a bug in the demo; it is a genuine, useful gotcha: printf() writes into a userspace stdio buffer, and only a flush (explicit fflush(), a full buffer, or the normal exit() library call) turns that buffer into an actual write() system call. _exit() is the raw system call for process termination and skips stdio cleanup entirely, so a buffered line that was never flushed is simply discarded. The same root cause explained the duplicate lines we initially saw from fork_demo.c and exec_demo.c before fflush(stdout) calls were added after each printf() that precedes a fork() or exec() — the child inherits a copy of the parent's still-unflushed buffer and can end up printing it a second time."
        ),

        h1("Conclusion"),
        p(
          "Part 1 established a working C toolchain (GCC 13.3.0), a Git repository with the standard init → add → commit → push workflow, a documented project layout, and a Makefile that builds every demo with a single command. Part 2 used that toolchain to build four small, independently verifiable programs that together cover process abstraction, fork(), the exec() family, multi-generation parent-child trees (cross-checked against pstree), and system-call tracing with strace — including one real debugging insight (buffered stdio vs. _exit()) that only appeared because the demos were actually run rather than just written."
        ),
      ],
    },
  ],
});

function readSrcTrimmed(rel) {
  return fs.readFileSync(path.join(__dirname, rel), "utf8").replace(/\n$/, "");
}

Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync(path.join(__dirname, "OSSP_Lab1_Report.docx"), buffer);
  console.log("Wrote OSSP_Lab1_Report.docx");
});
