/*
 * exec_demo.c
 * ------------------------------------------------------------
 * OSSP Lab - Task 2: The exec() Family
 *
 * Demonstrates:
 *   - fork() + exec() is the standard Unix pattern for running a
 *     new program (fork() gives you a new process, exec() replaces
 *     that process's memory image with a different program)
 *   - Two members of the exec() family: execl() and execvp()
 *   - Code AFTER a successful exec() call never runs, because the
 *     old program image (and everything after that line) is gone
 * ------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void) {
    printf("[PARENT] Starting, PID=%d\n", getpid());
    fflush(stdout);

    /* ---- Child #1: execl() -> runs /bin/echo with a fixed arg list ---- */
    pid_t pid1 = fork();
    if (pid1 == 0) {
        printf("[CHILD1] PID=%d about to execl(/bin/echo ...)\n", getpid());
        fflush(stdout);
        execl("/bin/echo", "echo", "Hello from execl() - I am a NEW program image now", (char *)NULL);
        /* only reached if execl() FAILS */
        perror("execl failed");
        exit(EXIT_FAILURE);
    }
    waitpid(pid1, NULL, 0);

    /* ---- Child #2: execvp() -> searches $PATH, takes an argv[] array ---- */
    pid_t pid2 = fork();
    if (pid2 == 0) {
        printf("[CHILD2] PID=%d about to execvp(ls -l src)\n", getpid());
        fflush(stdout);
        char *args[] = {"ls", "-l", "src", NULL};
        execvp("ls", args);
        /* only reached if execvp() FAILS */
        perror("execvp failed");
        exit(EXIT_FAILURE);
    }
    waitpid(pid2, NULL, 0);

    printf("[PARENT] Both children finished. PID=%d exiting.\n", getpid());
    fflush(stdout);
    return 0;
}
