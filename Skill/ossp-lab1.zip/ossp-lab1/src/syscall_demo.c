/*
 * syscall_demo.c
 * ------------------------------------------------------------
 * OSSP Lab - Task 2: System Call Tracing
 *
 * This program deliberately makes a handful of very visible system
 * calls (open, write, read, close, fork, exit) so that its behaviour
 * is easy to recognise inside an `strace` trace. Trace it with:
 *
 *     strace -f -o trace_output.txt ./syscall_demo
 *
 * -f  -> follow child processes created by fork() as well
 * -o  -> write the trace to a file instead of the terminal
 * ------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

int main(void) {
    const char *filename = "syscall_demo_scratch.txt";
    const char *message = "System call tracing demo\n";

    /* 1. open() - creates/opens a file (visible in strace as openat) */
    int fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (fd < 0) {
        perror("open");
        exit(EXIT_FAILURE);
    }

    /* 2. write() - writes bytes to the file descriptor */
    write(fd, message, strlen(message));

    /* 3. close() - releases the file descriptor */
    close(fd);

    /* 4. open() again for reading, then read() it back */
    fd = open(filename, O_RDONLY);
    char buf[64] = {0};
    read(fd, buf, sizeof(buf) - 1);
    close(fd);
    printf("Read back from file: %s", buf);

    /* 5. fork() + wait() - visible as fork/clone + wait4 in the trace */
    pid_t pid = fork();
    if (pid == 0) {
        printf("Child PID=%d saying hello, then exiting\n", getpid());
        _exit(0);
    }
    wait(NULL);

    printf("Parent PID=%d done.\n", getpid());
    return 0;
}
