/*
 * process_tree.c
 * ------------------------------------------------------------
 * OSSP Lab - Task 2: Parent-Child Relationships & Process Tree
 *
 * Demonstrates:
 *   - A parent creating multiple children (a "fan out")
 *   - A child that itself forks again, creating a grandchild
 *     (so the tree has 3 generations: parent -> child -> grandchild)
 *   - Reading PID/PPID at every generation to see the tree shape
 *   - While the grandchildren are still alive (sleeping), the root
 *     parent shells out to `pstree -p` so you can see the SAME tree
 *     reported by the operating system itself
 * ------------------------------------------------------------
 */

#define _DEFAULT_SOURCE /* exposes usleep() under -std=c11 (strict ISO C mode) */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define NUM_CHILDREN 2

static void grandchild_work(int id) {
    printf("      [GRANDCHILD %d] PID=%d  PPID=%d (child of a child)\n",
           id, getpid(), getppid());
    fflush(stdout);
    sleep(2); /* stay alive long enough for the parent to snapshot the tree */
}

static void child_work(int id) {
    printf("  [CHILD %d] PID=%d  PPID=%d\n", id, getpid(), getppid());
    fflush(stdout);

    /* each child spawns ONE grandchild to grow the tree another level */
    pid_t gpid = fork();
    if (gpid == 0) {
        grandchild_work(id);
        exit(0);
    }
    waitpid(gpid, NULL, 0);
}

int main(void) {
    pid_t root_pid = getpid();
    printf("[ROOT PARENT] PID=%d  PPID=%d\n", root_pid, getppid());
    fflush(stdout);

    for (int i = 1; i <= NUM_CHILDREN; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            child_work(i);
            exit(0);
        }
    }

    /* give children/grandchildren a moment to start and print before we snapshot */
    usleep(300000);

    printf("\n[ROOT PARENT] Live snapshot of this process's own subtree "
           "(PID %d) while grandchildren are still alive:\n", root_pid);
    fflush(stdout);
    char cmd[64];
    snprintf(cmd, sizeof(cmd), "pstree -p %d", root_pid);
    system(cmd);
    printf("\n");
    fflush(stdout);

    /* parent waits for all direct children (which wait for their own grandchild) */
    for (int i = 0; i < NUM_CHILDREN; i++) {
        wait(NULL);
    }

    printf("[ROOT PARENT] all children/grandchildren finished.\n");
    return 0;
}
