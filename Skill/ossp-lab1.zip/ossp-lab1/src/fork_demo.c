/*
 * fork_demo.c
 * ------------------------------------------------------------
 * OSSP Lab - Task 2: Process Abstraction & fork()
 *
 * Demonstrates:
 *   - A process as an "abstraction" the OS gives a running program
 *     (its own PID, its own address space, its own copy of data)
 *   - How fork() creates a near-identical copy of the calling
 *     process (the "child"), and how the return value of fork()
 *     is the ONLY way the parent and child can tell themselves apart
 *   - wait() so the parent does not finish before the child
 * ------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void) {
    int shared_looking_variable = 100; /* each process gets its OWN copy after fork */

    printf("[BEFORE FORK] PID=%d PPID=%d variable=%d\n",
           getpid(), getppid(), shared_looking_variable);
    fflush(stdout); /* flush BEFORE fork() so the child doesn't inherit
                        an unflushed copy of this line in its stdio buffer */

    pid_t pid = fork();

    if (pid < 0) {
        /* fork failed - no child was created */
        perror("fork failed");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        /* ---------------- CHILD PROCESS ---------------- */
        shared_looking_variable += 50; /* only changes the CHILD's copy */
        printf("[CHILD ] PID=%d  PPID=%d  fork() returned=%d  variable=%d\n",
               getpid(), getppid(), pid, shared_looking_variable);
        exit(42); /* exit code the parent will read via wait() */
    } else {
        /* ---------------- PARENT PROCESS ---------------- */
        int status;
        pid_t child_pid = wait(&status); /* block until the child finishes */

        printf("[PARENT] PID=%d  PPID=%d  fork() returned=%d  variable=%d\n",
               getpid(), getppid(), pid, shared_looking_variable);

        if (WIFEXITED(status)) {
            printf("[PARENT] child PID=%d exited with code %d\n",
                   child_pid, WEXITSTATUS(status));
        }
    }

    return 0;
}
